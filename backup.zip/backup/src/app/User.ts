export class User {
    id:number;
    name:string;
    author:string;
    price:number
}